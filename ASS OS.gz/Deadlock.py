"""Deadlock.py
Demonstrates a possible deadlock scenario and a resolved approach.
The file contains two demonstrations:
1) simulate_deadlock() - shows how deadlock *can* happen (uses timeouts so it won't hang)
2) avoid_deadlock_ordering() - shows a safe approach (acquire locks in a consistent order)
Author: Ahmed Mohamed Gamal Saad - 212102783
"""
import threading
import time

lock_a = threading.Lock()
lock_b = threading.Lock()

def simulate_deadlock():
    """Two threads try to acquire locks in opposite order.
    To avoid the script hanging while demonstrating, we use acquire(timeout=...) and detect failure.
    """
    def t1():
        print("T1: acquiring lock A")
        lock_a.acquire()
        print("T1: acquired lock A")
        time.sleep(0.2)
        print("T1: trying to acquire lock B (will timeout if deadlock)")
        got = lock_b.acquire(timeout=1.0)
        if not got:
            print("T1: failed to acquire lock B -> deadlock detected (simulated)")
        else:
            print("T1: acquired lock B")
            lock_b.release()
        lock_a.release()
        print("T1: released lock A and exiting")

    def t2():
        print("T2: acquiring lock B")
        lock_b.acquire()
        print("T2: acquired lock B")
        time.sleep(0.2)
        print("T2: trying to acquire lock A (will timeout if deadlock)")
        got = lock_a.acquire(timeout=1.0)
        if not got:
            print("T2: failed to acquire lock A -> deadlock detected (simulated)")
        else:
            print("T2: acquired lock A")
            lock_a.release()
        lock_b.release()
        print("T2: released lock B and exiting")

    ta = threading.Thread(target=t1, name='T1')
    tb = threading.Thread(target=t2, name='T2')
    ta.start()
    tb.start()
    ta.join()
    tb.join()
    print("simulate_deadlock: demo finished\n")

def avoid_deadlock_ordering():
    """Resolve deadlock by always acquiring locks in the same order.
    Here both threads acquire lock_a first, then lock_b.
    """
    def t(name):
        print(f"{name}: acquiring lock A")
        with lock_a:
            print(f"{name}: acquired lock A")
            time.sleep(0.1)
            print(f"{name}: acquiring lock B")
            with lock_b:
                print(f"{name}: acquired lock B")
                time.sleep(0.1)
        print(f"{name}: released both locks and exiting")

    ta = threading.Thread(target=lambda: t('T1'), name='T1-safe')
    tb = threading.Thread(target=lambda: t('T2'), name='T2-safe')
    ta.start()
    tb.start()
    ta.join()
    tb.join()
    print("avoid_deadlock_ordering: demo finished\n")

if __name__ == '__main__':
    print('\n== Deadlock demonstration (with timeouts to avoid hanging) ==\n')
    simulate_deadlock()
    print('\n== Deadlock avoidance via consistent ordering ==\n')
    avoid_deadlock_ordering()
