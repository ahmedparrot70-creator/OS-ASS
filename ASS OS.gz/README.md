# Python Concurrency Assignment
Repo created for: Ahmed Mohamed Gamal Saad - 212102783

Contains three demonstration files:
- Threading.py : simple thread creation and join example
- Deadlock.py  : demonstrates a deadlock scenario (with timeouts) and a resolved approach using ordering
- Semaphore.py : demonstrates using a Semaphore to limit concurrency

Run each file with Python 3.8+:
```bash
python Threading.py
python Deadlock.py
python Semaphore.py
```
\nCompleted assignment and verified files.\n