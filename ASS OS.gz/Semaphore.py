"""Semaphore.py
Demonstrates using threading.Semaphore to limit concurrent access to a resource (e.g. DB connections).
Author: Ahmed Mohamed Gamal Saad - 212102783
"""
import threading
import time
import random

# allow up to 3 concurrent workers
sem = threading.Semaphore(3)

def worker(n):
    print(f"Worker-{n} waiting to acquire semaphore")
    with sem:
        print(f"Worker-{n} acquired semaphore - working")
        # simulate work
        time.sleep(0.6 + random.random() * 0.4)
        print(f"Worker-{n} releasing semaphore")


def main():
    threads = []
    for i in range(8):
        t = threading.Thread(target=worker, args=(i+1,))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

    print("All worker threads finished")


if __name__ == '__main__':
    main()
