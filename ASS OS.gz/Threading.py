"""Threading.py
Simple demo showing starting multiple threads, work distribution and joining.
Author: Ahmed Mohamed Gamal Saad - 212102783
"""
import threading
import time
import random

def worker(n):
    """Thread worker function: prints start, sleeps, prints finish."""
    print(f"[Thread-{n}] starting")
    # simulate variable work
    time.sleep(0.5 + random.random() * 0.5)
    print(f"[Thread-{n}] finished")


def main():
    threads = []
    num_threads = 5
    print("Main: creating threads")
    for i in range(num_threads):
        t = threading.Thread(target=worker, args=(i+1,), name=f"Worker-{i+1}")
        threads.append(t)
        t.start()

    print("Main: waiting for threads to finish (join)")
    for t in threads:
        t.join()

    print("Main: all threads have finished")


if __name__ == '__main__':
    main()
