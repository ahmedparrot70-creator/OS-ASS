import threading
import time

sema = threading.Semaphore(2)

def worker(id):
    sema.acquire()
    print(f"Worker {id} started")
    time.sleep(1)
    print(f"Worker {id} finished")
    sema.release()

for i in range(5):
    t = threading.Thread(target=worker, args=(i,))
    t.start()
