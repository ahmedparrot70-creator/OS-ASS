import threading
import time

def print_numbers():
    for i in range(5):
        print("Thread:", i)
        time.sleep(0.5)

t = threading.Thread(target=print_numbers)
t.start()
t.join()

print("Threading example completed")
